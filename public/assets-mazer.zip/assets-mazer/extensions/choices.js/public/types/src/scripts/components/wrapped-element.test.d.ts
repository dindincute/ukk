export {};
//# sourceMappingURL=wrapped-element.test.d.ts.map