
import DataTable from 'datatables.net';

export default DataTable;
export * from 'datatables.net';
